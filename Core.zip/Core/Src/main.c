/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2022 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "i2c-lcd.h"

#include <stdio.h>

#include <string.h>

#include "hx711.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim15;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM15_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
hx711_t loadcell;
float weight;
char weight_str[40];
void delay(uint16_t time) {
   __HAL_TIM_SET_COUNTER( & htim15, 0);
   while (__HAL_TIM_GET_COUNTER( & htim15) < time);
}

uint32_t IC_Val1 = 0;
uint32_t IC_Val2 = 0;
uint32_t Difference = 0;
uint8_t Is_First_Captured = 0; // is the first value captured ?
uint8_t Distance = 0;
char height_str[40], BMI_st[20];
uint8_t distance_total = 190, height = 0, BMI;
#define TRIG_PIN GPIO_PIN_15
#define TRIG_PORT GPIOB

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef * htim) {
   if (htim -> Channel == HAL_TIM_ACTIVE_CHANNEL_1) // if the interrupt source is channel1
   {
      if (Is_First_Captured == 0) // if the first value is not captured
      {
         IC_Val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1); // read the first value
         Is_First_Captured = 1; // set the first captured as true
         // Now change the polarity to falling edge
         __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
      } else if (Is_First_Captured == 1) // if the first is already captured
      {
         IC_Val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1); // read second value
         __HAL_TIM_SET_COUNTER(htim, 0); // reset the counter

         if (IC_Val2 > IC_Val1) {
            Difference = IC_Val2 - IC_Val1;
         } else if (IC_Val1 > IC_Val2) {
            Difference = (0xffff - IC_Val1) + IC_Val2;
         }

         Distance = Difference * .036 / 2;
         Is_First_Captured = 0; // set it back to false

         // set polarity to rising edge
         __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
         __HAL_TIM_DISABLE_IT( & htim15, TIM_IT_CC1);
      }
   }
}

void HCSR04_Read(void) {
   HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_SET); // pull the TRIG pin HIGH
   delay(10); // wait for 10 us
   HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET); // pull the TRIG pin low

   __HAL_TIM_ENABLE_IT( & htim15, TIM_IT_CC1);
}

int r = 0;
char rcv_char[250];
#define RxBuf_SIZE 250
#define MainBuf_SIZE 250

uint8_t RxBuf[RxBuf_SIZE];
uint8_t MainBuf[MainBuf_SIZE];

uint16_t oldPos = 0;
uint16_t newPos = 0;
int age_st = 1, gender_st = 1, weight_st = 1, height_st = 1, age_max = 5;
char gender[40], BMI_st[20], age_str[3];
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef * huart, uint16_t Size) {
   if (huart -> Instance == USART2) {
      oldPos = newPos; // Update the last position before copying new data

      /* If the data in large and it is about to exceed the buffer size, we have to route it to the start of the buffer
       * This is to maintain the circular buffer
       * The old data in the main buffer will be overlapped
       */
      if (oldPos + Size > MainBuf_SIZE) // If the current position + new data size is greater than the main buffer
      {
         uint16_t datatocopy = MainBuf_SIZE - oldPos; // find out how much space is left in the main buffer
         memcpy((uint8_t * ) MainBuf + oldPos, RxBuf, datatocopy); // copy data in that remaining space

         oldPos = 0; // point to the start of the buffer
         memcpy((uint8_t * ) MainBuf, (uint8_t * ) RxBuf + datatocopy, (Size - datatocopy)); // copy the remaining data
         newPos = (Size - datatocopy); // update the position
      }

      /* if the current position + new data size is less than the main buffer
       * we will simply copy the data into the buffer and update the position
       */
      else {
         memcpy((uint8_t * ) MainBuf + oldPos, RxBuf, Size);
         newPos = Size + oldPos;
      }

      r = 1;
      /* start the DMA again */
      HAL_UARTEx_ReceiveToIdle_DMA( & huart2, (uint8_t * ) RxBuf, RxBuf_SIZE);
      __HAL_DMA_DISABLE_IT( & hdma_usart2_rx, DMA_IT_HT);

   }
}

void GSM_init() {

   uint16_t gsm_time;
   uint16_t gsm_time_diff;
   int gsm_timeout;
   int AT_command;
   char ATOK[50];
   char reply_char[50];
   lcd_cursor(0, 1, "Starting...");
   HAL_UART_Transmit( & huart2, (uint8_t * )
      "AT\r\n", strlen("AT\r\n "), 10);
   gsm_time = HAL_GetTick();
   gsm_timeout = 2000;
   AT_command = 0;

   while (1) {
	  // HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
      gsm_time_diff = HAL_GetTick() - gsm_time;

      if (AT_command == 0) {
         sprintf(ATOK, "%s", "AT\r\n");
         sprintf(reply_char, "%s", "ATOK");
      } else if (AT_command == 1) {
         sprintf(ATOK, "%s", "ATE1\r\n");
         sprintf(reply_char, "%s", "ATE1OK");
      } else if (AT_command == 2) {
         sprintf(ATOK, "%s", "AT+CPIN?\r\n");
         sprintf(reply_char, "%s", "AT+CPIN?+CPIN: READY");
      }

      if (gsm_time_diff > gsm_timeout) {
         //  HAL_UART_Transmit(&huart1,(uint8_t *)"\nRetrying ", strlen("Retrying  "), 10);
         HAL_UART_Transmit( & huart2, (uint8_t * ) ATOK, strlen(ATOK), 10);
         //HAL_UART_Transmit(&huart1,(uint8_t *)ATOK, strlen(ATOK), 10);
         gsm_time = HAL_GetTick();
      }

      if (r == 1) {
         sprintf(rcv_char, "%s", RxBuf);
         //HAL_UART_Transmit(&huart1,(uint8_t *)"\nReceived: ", strlen("Received: "), 10);
         //HAL_UART_Transmit(&huart1,(uint8_t *)rcv_char, strlen(rcv_char)+1, 30);

         for (int i = 0; i <= sizeof(RxBuf); i++) {
            if (AT_command == 0 && RxBuf[i] == 'O' && RxBuf[i + 1] == 'K') {

               // HAL_UART_Transmit(&huart1,(uint8_t *)"\nModule connected", strlen("Module connected "), 20);
               //HAL_UART_Transmit(&huart1,(uint8_t *)"\nDisabling ECHO", strlen("Disabling ECHO "), 20);
               lcd_clear();
               lcd_cursor(0, 0, "  ***VPIMS***");
               lcd_cursor(0, 1, "Checking Service");
               AT_command = 1;

            } else if (AT_command == 1 && RxBuf[i] == 'O' && RxBuf[i + 1] == 'K') {

               // HAL_UART_Transmit(&huart1,(uint8_t *)"\nECHO Disabled", strlen("Echo Disabled "), 20);
               // HAL_UART_Transmit(&huart1,(uint8_t *)"\nFinding Network", strlen("Finding network "), 20);
               lcd_clear();
               lcd_cursor(0, 0, "  ***VPIMS***");
               lcd_cursor(0, 1, "Finding Network");
               AT_command = 2;

            } else if (AT_command == 2 && RxBuf[i] == 'R' && RxBuf[i + 1] == 'E' && RxBuf[i + 2] == 'A' && RxBuf[i + 3] == 'D' && RxBuf[i + 4] == 'Y') {

               //HAL_UART_Transmit(&huart1,(uint8_t *)"\nNetwork Found", strlen("Network Found "), 20);
               lcd_clear();
               lcd_cursor(0, 0, "  ***VPIMS***");
               lcd_cursor(0, 1, "Network Found");
               AT_command = 3;
               break;

            }
         }
         memset( & RxBuf[0], 0, sizeof(RxBuf));

         r = 0;

      }
      if (AT_command == 3) {
         break;
      }
   }

   //HAL_UART_Transmit(&huart1,(uint8_t *)"\nSystem ready", strlen("System ready"), 20);
   HAL_Delay(2000);
   lcd_clear();
   lcd_cursor(0, 0, "  ***VPIMS***");
   lcd_cursor(0, 1, "System Ready");
   HAL_Delay(1000);
   HAL_UART_Transmit( & huart2, (uint8_t * )
      "AT\r\n", strlen("AT\r"), 10);
   HAL_UART_Transmit( & huart2, (uint8_t * )
      "AT+CMGF=1\r\n", strlen("AT+CMGF=1"), 10);
   HAL_UART_Transmit( & huart2, (uint8_t * )
      "AT+CNMI=2,2,0,0,0\r\n", strlen("AT+CNMI=2,2,0,0,0"), 10);
   HAL_UART_Transmit( & huart2, (uint8_t * )
      "AT+CGMR\r\n", strlen("AT+CGMR"), 10);

}

void set_age() {

   lcd_clear();
   lcd_cursor(0, 0, "Enter Age(5-19)");
   lcd_cursor(0, 1, "Age: 5");
   age_max = 5;
   while (1) {
      if (!HAL_GPIO_ReadPin(GPIOA, up_Pin)) {
         age_max++;
         if (age_max > 19) {
            age_max = 5;
         }
         sprintf(age_str, "%d", age_max);
         lcd_cursor(5, 1, "       ");
         lcd_cursor(5, 1, age_str);
         HAL_Delay(200);
      }

      if (!HAL_GPIO_ReadPin(GPIOA, down_Pin)) {
         age_max--;
         if (age_max < 5) {
            age_max = 19;
         }
         sprintf(age_str, "%d", age_max);
         lcd_cursor(5, 1, "       ");
         lcd_cursor(5, 1, age_str);
         HAL_Delay(200);
      }

      if (!HAL_GPIO_ReadPin(GPIOA, enter_Pin)) {
         age_st = 1, gender_st = 0;
         lcd_clear();
         lcd_cursor(0, 0, "Setting Age");
         lcd_cursor(0, 1, "Successfully");
         HAL_Delay(1000);
         break;

      }

   }
}

void set_gender() {

   lcd_clear();
   lcd_cursor(0, 0, "Choose gender");
   HAL_Delay(1000);
   lcd_clear();
   lcd_cursor(0, 0, "Male");
   lcd_cursor(0, 1, "Female");
   int curs_pos = 0;
   sprintf(gender, "%s", "male");
   lcd_cursor(4, 0, "<");
   while (1) {

      if (!HAL_GPIO_ReadPin(GPIOA, down_Pin)) {
         memset( & gender[0], 0, sizeof(gender));
         if (curs_pos == 0) {
            curs_pos = 1;
            lcd_cursor(4, 0, "  ");
            lcd_cursor(6, 1, "<");
            sprintf(gender, "%s", "F");
         } else if (curs_pos == 1) {
            curs_pos = 0;
            lcd_cursor(6, 1, "  ");
            lcd_cursor(4, 0, "<");
            sprintf(gender, "%s", "M");
         }
         HAL_Delay(200);
      }

      if (!HAL_GPIO_ReadPin(GPIOA, up_Pin)) {
         memset( & gender[0], 0, sizeof(gender));
         if (curs_pos == 0) {
            curs_pos = 1;
            lcd_cursor(4, 0, "  ");
            lcd_cursor(6, 1, "<");
            sprintf(gender, "%s", "F");
         } else if (curs_pos == 1) {
            curs_pos = 0;
            lcd_cursor(6, 1, "  ");
            lcd_cursor(4, 0, "<");
            sprintf(gender, "%s", "M");
         }
         HAL_Delay(200);
      }

      if (!HAL_GPIO_ReadPin(GPIOA, enter_Pin)) {
         age_st = 1, gender_st = 1, weight_st = 0;
         lcd_clear();
         lcd_cursor(0, 0, "Setting Gender");
         lcd_cursor(0, 1, "Successfully");
         HAL_Delay(1000);
         break;

      }
   }

}

void set_weight() {
   lcd_clear();
   lcd_cursor(0, 0, "Step on scale");
   while (1) {

      weight = hx711_weight( & loadcell, 10) - 31600;
      if (weight < 10) {
         weight = 0;
      }
      memset( & weight_str[0], 0, sizeof(weight_str));
      sprintf(weight_str, "Weight: %0.1fkg", weight / 1000);
      lcd_cursor(0, 1, "               ");
      lcd_cursor(0, 1, weight_str);

      if (!HAL_GPIO_ReadPin(GPIOA, enter_Pin)) {
         age_st = 1, gender_st = 1, weight_st = 1, height_st = 0;
         lcd_clear();
         lcd_cursor(0, 0, "Setting Weight");
         lcd_cursor(0, 1, "Successfully");
         HAL_Delay(1000);
         break;

      }

   }

}

void SendSMS(uint8_t * sms_string, uint8_t * phone_string) {

   char sms_char[2000];
   char phn_char[20];
   char ctrz[10];

   sprintf(phn_char, "AT+CMGS=\"%s\"\r\n", phone_string);
   HAL_UART_Transmit( & huart2, (uint8_t * )
      "AT+CMGF=1\r\n", strlen("AT+CMGF=1\r\n"), 20);
   HAL_Delay(1000);
   HAL_UART_Transmit( & huart2, (uint8_t * ) phn_char, strlen(phn_char), 20);
   HAL_Delay(1000);
   sprintf(sms_char, "%s\r\n", sms_string);
   HAL_UART_Transmit( & huart2, (uint8_t * ) sms_char, strlen(sms_char), 100);
   HAL_Delay(100);
   sprintf(ctrz, "%c\r\n", 0x1a);
   HAL_UART_Transmit( & huart2, (uint8_t * ) ctrz, strlen(ctrz), 5);
   HAL_Delay(1000);

}

void set_height() {
   lcd_clear();
   lcd_cursor(0, 0, "Measure Height");
   char weight_height[60];
   while (1) {
	   memset( & height_str[0], 0, sizeof(height_str));
      HCSR04_Read();
      height = distance_total - Distance;

      sprintf(height_str, "Height: %0.1fcm", height*1.00);
      lcd_cursor(0, 1, "               ");
      lcd_cursor(0, 1, height_str);
      HAL_Delay(200);

      if (!HAL_GPIO_ReadPin(GPIOA, enter_Pin)) {
         age_st = 1, gender_st = 1, weight_st = 1, height_st = 1;

         BMI = 0.001 * weight / (0.01 * height * 0.01 * height);
         if (BMI < 18.5) {
            sprintf(BMI_st, "%s", "underweight");

         } else if (BMI >= 18.5 && BMI <= 24.9) {
            sprintf(BMI_st, "%s", "normalweight");

         } else if (BMI >= 25.0 && BMI <= 29.9) {
            sprintf(BMI_st, "%s", "overweight");

         } else if (BMI > 30.0) {
            sprintf(BMI_st, "%s", "obesity");
         }
         sprintf(weight_height, "H:%0.1fcm W:%0.1fKG", height*1.00, weight / 1000);

         lcd_clear();
         lcd_cursor(0, 0, weight_height);
         lcd_cursor(0, 1, BMI_st);

         HAL_Delay(5000);
         lcd_clear();
         lcd_cursor(0, 0, "Sending SMS...");
         lcd_cursor(0, 1, "Please wait...");
         char sms_content[3000];
         sprintf(sms_content, "VPIMS %d %s %0.1f %0.1f %s %s\r\n", age_max, gender, weight / 1000,height*1.00, BMI_st, "+255692244163");
         SendSMS((uint8_t * ) sms_content, (uint8_t * )
            "+255757650442");
         lcd_clear();
         lcd_cursor(0, 0, "     Done");
         memset( & height_str[0], 0, sizeof(height_str));
         memset( & weight_str[0], 0, sizeof(weight_str));
         memset( & weight_height[0], 0, sizeof(weight_height));
         memset( & gender[0], 0, sizeof(gender));
         memset( & BMI_st[0], 0, sizeof(BMI_st));
         memset( & sms_content[0], 0, sizeof(sms_content));
         memset( & age_str[0], 0, sizeof(age_str));
         weight = 0, height = 0, age_max = 0;
         HAL_Delay(1000);
         lcd_clear();
         lcd_cursor(0, 0, "Press 'START'");
         lcd_cursor(0, 1, "To initialize");
         break;

      }

   }
}

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
   /* USER CODE BEGIN 1 */

   /* USER CODE END 1 */

   /* MCU Configuration--------------------------------------------------------*/

   /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
   HAL_Init();

   /* USER CODE BEGIN Init */

   /* USER CODE END Init */

   /* Configure the system clock */
   SystemClock_Config();

   /* USER CODE BEGIN SysInit */

   /* USER CODE END SysInit */

   /* Initialize all configured peripherals */
   MX_GPIO_Init();
   MX_DMA_Init();
   MX_I2C1_Init();
   MX_USART2_UART_Init();
   MX_TIM15_Init();
   MX_TIM1_Init();
   /* USER CODE BEGIN 2 */
   HAL_Delay(2000);
   HAL_TIM_Base_Start_IT( & htim1);
   HAL_UARTEx_ReceiveToIdle_DMA( & huart2, RxBuf, RxBuf_SIZE);
   __HAL_DMA_DISABLE_IT( & hdma_usart2_rx, DMA_IT_HT);

   HAL_TIM_Base_Start_IT( & htim1);
   hx711_init( & loadcell, clk_GPIO_Port, clk_Pin, dat_GPIO_Port, dat_Pin);
   hx711_coef_set( & loadcell, 26.0); // read afer calibration
   hx711_tare( & loadcell, 10);
   HAL_Delay(500);
   HAL_TIM_IC_Start_IT( & htim15, TIM_CHANNEL_1);
   lcd_init();
   lcd_clear();
   lcd_cursor(0, 0, "  ***VPIMS***");
   GSM_init();
   HAL_Delay(2000);
   SendSMS((uint8_t * )"System ready", (uint8_t * )
              "+255788570095");
   lcd_clear();
   lcd_cursor(0, 0, "Press 'START'");
   lcd_cursor(0, 1, "To initialize");
   /* USER CODE END 2 */

   /* Infinite loop */
   /* USER CODE BEGIN WHILE */
   while (1) {
      /* USER CODE END WHILE */

      /* USER CODE BEGIN 3 */

      if (!HAL_GPIO_ReadPin(GPIOA, start_Pin)) {

         age_st = 0;

      }
      if (age_st == 0) {
         set_age();
      } else if (gender_st == 0) {
         set_gender();
      } else if (weight_st == 0) {
         set_weight();
      } else if (height_st == 0) {
         set_height();
      }
   }

   /* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
   RCC_OscInitTypeDef RCC_OscInitStruct = {
      0
   };
   RCC_ClkInitTypeDef RCC_ClkInitStruct = {
      0
   };
   RCC_PeriphCLKInitTypeDef PeriphClkInit = {
      0
   };

   /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
   RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
   RCC_OscInitStruct.HSIState = RCC_HSI_ON;
   RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
   RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
   RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
   RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
   RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
   if (HAL_RCC_OscConfig( & RCC_OscInitStruct) != HAL_OK) {
      Error_Handler();
   }

   /** Initializes the CPU, AHB and APB buses clocks
    */
   RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
      RCC_CLOCKTYPE_PCLK1;
   RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
   RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
   RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

   if (HAL_RCC_ClockConfig( & RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK) {
      Error_Handler();
   }
   PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;
   PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
   if (HAL_RCCEx_PeriphCLKConfig( & PeriphClkInit) != HAL_OK) {
      Error_Handler();
   }
}

/**
 * @brief I2C1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_I2C1_Init(void) {

   /* USER CODE BEGIN I2C1_Init 0 */

   /* USER CODE END I2C1_Init 0 */

   /* USER CODE BEGIN I2C1_Init 1 */

   /* USER CODE END I2C1_Init 1 */
   hi2c1.Instance = I2C1;
   hi2c1.Init.Timing = 0x2000090E;
   hi2c1.Init.OwnAddress1 = 0;
   hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
   hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
   hi2c1.Init.OwnAddress2 = 0;
   hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
   hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
   hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
   if (HAL_I2C_Init( & hi2c1) != HAL_OK) {
      Error_Handler();
   }

   /** Configure Analogue filter
    */
   if (HAL_I2CEx_ConfigAnalogFilter( & hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK) {
      Error_Handler();
   }

   /** Configure Digital filter
    */
   if (HAL_I2CEx_ConfigDigitalFilter( & hi2c1, 0) != HAL_OK) {
      Error_Handler();
   }
   /* USER CODE BEGIN I2C1_Init 2 */

   /* USER CODE END I2C1_Init 2 */

}

/**
 * @brief TIM1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM1_Init(void) {

   /* USER CODE BEGIN TIM1_Init 0 */

   /* USER CODE END TIM1_Init 0 */

   TIM_ClockConfigTypeDef sClockSourceConfig = {
      0
   };
   TIM_MasterConfigTypeDef sMasterConfig = {
      0
   };

   /* USER CODE BEGIN TIM1_Init 1 */

   /* USER CODE END TIM1_Init 1 */
   htim1.Instance = TIM1;
   htim1.Init.Prescaler = 0;
   htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
   htim1.Init.Period = 65535;
   htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
   htim1.Init.RepetitionCounter = 0;
   htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
   if (HAL_TIM_Base_Init( & htim1) != HAL_OK) {
      Error_Handler();
   }
   sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_ETRMODE2;
   sClockSourceConfig.ClockPolarity = TIM_CLOCKPOLARITY_NONINVERTED;
   sClockSourceConfig.ClockPrescaler = TIM_CLOCKPRESCALER_DIV1;
   sClockSourceConfig.ClockFilter = 15;
   if (HAL_TIM_ConfigClockSource( & htim1, & sClockSourceConfig) != HAL_OK) {
      Error_Handler();
   }
   sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
   sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
   if (HAL_TIMEx_MasterConfigSynchronization( & htim1, & sMasterConfig) != HAL_OK) {
      Error_Handler();
   }
   /* USER CODE BEGIN TIM1_Init 2 */

   /* USER CODE END TIM1_Init 2 */

}

/**
 * @brief TIM15 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM15_Init(void) {

   /* USER CODE BEGIN TIM15_Init 0 */

   /* USER CODE END TIM15_Init 0 */

   TIM_MasterConfigTypeDef sMasterConfig = {
      0
   };
   TIM_IC_InitTypeDef sConfigIC = {
      0
   };

   /* USER CODE BEGIN TIM15_Init 1 */

   /* USER CODE END TIM15_Init 1 */
   htim15.Instance = TIM15;
   htim15.Init.Prescaler = 48;
   htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
   htim15.Init.Period = 0xffff - 1;
   htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
   htim15.Init.RepetitionCounter = 0;
   htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
   if (HAL_TIM_IC_Init( & htim15) != HAL_OK) {
      Error_Handler();
   }
   sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
   sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
   if (HAL_TIMEx_MasterConfigSynchronization( & htim15, & sMasterConfig) != HAL_OK) {
      Error_Handler();
   }
   sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
   sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
   sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
   sConfigIC.ICFilter = 0;
   if (HAL_TIM_IC_ConfigChannel( & htim15, & sConfigIC, TIM_CHANNEL_1) != HAL_OK) {
      Error_Handler();
   }
   /* USER CODE BEGIN TIM15_Init 2 */

   /* USER CODE END TIM15_Init 2 */

}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void) {

   /* USER CODE BEGIN USART2_Init 0 */

   /* USER CODE END USART2_Init 0 */

   /* USER CODE BEGIN USART2_Init 1 */

   /* USER CODE END USART2_Init 1 */
   huart2.Instance = USART2;
   huart2.Init.BaudRate = 115200;
   huart2.Init.WordLength = UART_WORDLENGTH_8B;
   huart2.Init.StopBits = UART_STOPBITS_1;
   huart2.Init.Parity = UART_PARITY_NONE;
   huart2.Init.Mode = UART_MODE_TX_RX;
   huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
   huart2.Init.OverSampling = UART_OVERSAMPLING_16;
   huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
   huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
   if (HAL_UART_Init( & huart2) != HAL_OK) {
      Error_Handler();
   }
   /* USER CODE BEGIN USART2_Init 2 */

   /* USER CODE END USART2_Init 2 */

}

/**
 * Enable DMA controller clock
 */
static void MX_DMA_Init(void) {

   /* DMA controller clock enable */
   __HAL_RCC_DMA1_CLK_ENABLE();

   /* DMA interrupt init */
   /* DMA1_Channel4_5_IRQn interrupt configuration */
   HAL_NVIC_SetPriority(DMA1_Channel4_5_IRQn, 0, 0);
   HAL_NVIC_EnableIRQ(DMA1_Channel4_5_IRQn);

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
   GPIO_InitTypeDef GPIO_InitStruct = {
      0
   };

   /* GPIO Ports Clock Enable */
   __HAL_RCC_GPIOC_CLK_ENABLE();
   __HAL_RCC_GPIOF_CLK_ENABLE();
   __HAL_RCC_GPIOA_CLK_ENABLE();
   __HAL_RCC_GPIOB_CLK_ENABLE();

   /*Configure GPIO pin Output Level */
   HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

   /*Configure GPIO pin Output Level */
   HAL_GPIO_WritePin(GPIOB, clk_Pin | GPIO_PIN_15, GPIO_PIN_RESET);

   /*Configure GPIO pin : PC13 */
   GPIO_InitStruct.Pin = GPIO_PIN_13;
   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(GPIOC, & GPIO_InitStruct);

   /*Configure GPIO pins : start_Pin down_Pin up_Pin enter_Pin */
   GPIO_InitStruct.Pin = start_Pin | down_Pin | up_Pin | enter_Pin;
   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   HAL_GPIO_Init(GPIOA, & GPIO_InitStruct);

   /*Configure GPIO pin : dat_Pin */
   GPIO_InitStruct.Pin = dat_Pin;
   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   HAL_GPIO_Init(dat_GPIO_Port, & GPIO_InitStruct);

   /*Configure GPIO pins : clk_Pin PB15 */
   GPIO_InitStruct.Pin = clk_Pin | GPIO_PIN_15;
   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(GPIOB, & GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
   /* USER CODE BEGIN Error_Handler_Debug */
   /* User can add his own implementation to report the HAL error return state */
   __disable_irq();
   while (1) {}
   /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t * file, uint32_t line) {
   /* USER CODE BEGIN 6 */
   /* User can add his own implementation to report the file name and line number,
      ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
   /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
