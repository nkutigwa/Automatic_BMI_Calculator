#ifndef _HX711CONFIG_H_
#define _HX711CONFIG_H_

#define		_HX711_USE_FREERTOS		0
#define   _HX711_DELAY_US_LOOP  4
#endif 
